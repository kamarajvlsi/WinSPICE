WinSpice3
---------

This is a port of Berkeley Spice3F5 to Win32.  The program works on
Windows 95 and hopefully it should run on Windows NT also although I
have no means of testing this.

I have to apologise for the way WinSpice3 works.  It is a very simple
port - partly because the effort I can apply is limited and partly
because I am not the worlds most experienced Windows programmer.  It
uses a command line interface within a window and only really uses
windows to display plots.  It is my intention to add schematic entry
of circuits and improve the integration with windows in future.

Documentation on WinSpice3 can be found in the 'doc' directory.  This
is in Word97 format (you can get a viewer from the Microsoft web page
if you don't have access to Word97).  There is also a tutorial document
and sample circuits in the 'tutorial' directory (also in Word97 format).

WinSpice3 contains all Spice3 built in devices and models with no
restrictions on memory usage.  If you find this program useful,
please send me an email or postcard with any bugs found or
suggestions.

Finally, for those people too impatient to read the docs, start up
WinSpice3 and then type 'demo' followed by the Enter key.  This will
run a script which analyses some demo circuits plotting graphs as it
goes.

Have fun!

Mike Smith
9th February 1999
mike@winspice.com

Postcards to:-  35 Rampton End
                Willingham
                Cambridge
                Cambridgeshire
                England
                CB4 5JB


********************************************************************
*                             HISTORY                              *
********************************************************************

*****************************
For WinSpice3 v1.05.07 onwards:-
*****************************

277. Fixes made to SW, CSW, ISWITCH and VSWITCH models for AC sensitivity.

278. A fix to prevent buffer overflow when expanding recursive macros.

279. A fix to allow a suffix on numbers in a .param line e.g.

.param VCC=12V

Previously, the internal expression evaluator would terminate at the first
of trouble and return only a partial result.


*****************************
For WinSpice3 v1.05.05 onwards:-
*****************************

271. Fixes made to sensitivity analysis code made by Richard Andresen.

272. Corrected the output from VP(2) etc so it expands to ph(v(2)) instead
of deg(ph(v(2))) if the 'set units=degrees' has been used.  This prevents
the double application of the radians to degrees conversion.

273. Fixed a problem where a capacitor defined like 'C n1 n2 C=<expression>'
was not having its capacitance expression evaluated during AC analysis.

274. Added support for defining an inductor value with an expression.

275. Fixed several .param substitution bugs. One day I'll get this stuff
sorted.

276. Fixed a problem in the expansion of idb() in Spice2 circuit files.

*****************************
For WinSpice3 v1.05.04 onwards:-
*****************************

266. Changed the expansion of vp() when used on a plot command line 
to give the phase in degrees rather than radians i.e. vp(x) => deg(ph(v(x)))
instead of vp(x) => ph(v(x)).

267. Improved 'listing expand' output to include .control/.endc lines and
*# lines.

268. Fixed overzealous .param expansion on lines like

*#set fred=1.0

to prevent 'fred' being expanded if '.param fred=56' existed elsewhere in the
circuit.

269. Fixed the filename handling for .lib, .library etc.  This never worked
for filenames with spaces in them.

270. Fixed a problem with the stag.cir example.  The parameter expansion
code was not recognising 'A' lines as used by the STAG device.

*****************************
For WinSpice3 v1.05.03 onwards:-
*****************************

262. Fixed the plot names written out by the 'write' command.

Previously, if 

    write out.txt i(v2)

was used, i(v2) would be written to the output file when this should
have been v2#branch.  This caused:-

    'Error: no such vector v2#branch'

if the file is loaded back in and an attempt is made to plot i(v2):-

    load out.txt 
    plot i(v2)

263. Corrected the VSWITCH and ISWITCH device code.  The PSpice equations I
took from the PSpice reference manual were wrong which meant that the
transition region was not switching properly.

264. Refined expansion between {} so that it does not expand if this is a shell
expansion like {$temp}.  This allows .PARAM definitions to be used inside
.control/.endc lines.

265. More fixes for parameter expansion to prevent node names being renamed if
a .param parameter has the same name as a node.

*****************************
For WinSpice3 v1.05.02 onwards:-
*****************************

258. Changed a #define in the WinSpice build to hopefully reduce memory leakage
by enabling code to clean up device models.

259. Added 'xunits <name>' and 'yunits <name>' option to the plot command so
that the correct units can be supplied to the plot by the user rather than
using defaults.

260. Fixed a problem where level 49 MOSFET devices would not be recognised.

261. Fixed a problem where level 49 MOSFETs had debugging enabled accidentally
so causing simulations to run slowly and also cause WinSpice to crash.

*****************************
For WinSpice3 v1.05.01 onwards:-
*****************************

252. Lots of fixes to the parameter code for better compatibility with PSpice.

253. Error reporting, when loading circuits, has been tidied up.

254. Fixed a problem where

plot phase(v(2))

would not give the correct plot.

255. Fixed an error parsing numbers with exponent in 'B' element expressions.

256. Reverted diode device to the Spice3 form.  A HSpice diode model can be
obtained by setting LEVEL=2 in the .model line.

257. Reverted the BSIM3 device to the original Spice3 model using LEVEL=8.  If
you use LEVEL=48, the BSIM3 device supports some HSpice parameters.

*****************************
For WinSpice3 v1.05.00 onwards:-
*****************************

251. v1.05.00 released.  This is basically the same as v1.04.22.

*****************************
For WinSpice3 v1.04.22 onwards:-
*****************************

247. Fixed a problem where the TIME variable would change during a DC analysis.
This turned out to be because the DC analysis code was using the circuit time
variable as a temporary number store!

248. More tweaks to the .PARAM code.  This fix changes how unbraced macros are
expanded.  For example:-

.PARAM VCC=2V 

...
VCC 23 45 50V
...

will result in

VCC 23 45 50V

and no longer result in

2V 23 45 50V

However, if curly braces are used, the expansion will be forced:-

{VCC} 23 45 50V

will be expanded to

2V 23 45 50V

249. A fix to prevent the 'repeat' statement forgetting the repeat count after
it has been executed.  This causes problems if a script jumped out of a repeat
loop into an outer loop.  Basically, previous to this fix, a repeat loop within
another loop would not have worked after the first pass through the outer loop.

250. Fixed an error generated when 'set numdgt=x' is used.


*****************************
For WinSpice3 v1.04.21 onwards:-
*****************************

243. Optimised the expression generated from the POLY directive.  This might make
some simulations more efficient.

244. Fixed a problem where .model lines nested with a parameterised subcircuit 
might not get inserted into the circuit during parameter expansion.

245. Fixed a problem parsing parameter lists like

.param val1={1},val2={2}

where no spaces separate the parameters.

246. Fixed a bug parsing function parameters in parameter expressions like

.PARAM RIN = {100 * sqrt(9)}


*****************************
For WinSpice3 v1.04.20 onwards:-
*****************************

242. Change 241 below did not work when setting an option.  The '.option'
shares code with the 'set' command but the .option directive was not handling
suffixes so that '.option rshunt=50m' would be treated as '.option rshunt=50'.

*****************************
For WinSpice3 v1.04.19 onwards:-
*****************************

238. Fixed a problem in the expansion of braced expressions with
nested braced expressions e.g.

.MODEL DDS D(BV={150*{0.0008*TEMP+0.98}} M=0.5  CJO=210p VJ=0.8)

Previously, the results from the inner braced expression were not being
used properly.

239. Fixed a problem parsing POLY directives in Exxx, Fxxx, Gxxx and Hxxx
lines.  More variations in the format of the POLY directive are now supported
for better compatability with 3rd party circuits and macromodels.  Also, the
expression generated from the POLY directive has been corrected.

240. Fixed problems with the B source expression parsing.  The parser was
failing to recognise some built-in functions.  Caused by a long-standing
typo which only caused a problem since new functions were added.

241. Made the 'set' command store values as strings until they are used when
the context is clearer.

*****************************
For WinSpice3 v1.04.18 onwards:-
*****************************

235. Added the 'MINCONVSHUNT=x' option to control how node shunting operates
during operating point analysis.  This option specifies the minimum allowed
shunt resistance and if set to zero, disable shunting.  Also, node shunting
only kicks in when source stepping and GMIN stepping have both failed to
work.

236. Reviewed the M=x parameter for the BSIM3 device versions.  The drain current
was not being scaled by M because the convoluted calculations ended up cancelling
out the M parameter.

237. Temporarily reversed change 217 pending further investigation.  Basically,
if a diode model is used with no parameters e.g. .model diode D(), defaulting
RS to 0.01 causes convergence problems.  This sort of diode is found in opamp
macromodels.

*****************************
For WinSpice3 v1.04.17 onwards:-
*****************************

227. Added support for Backward Euler integration.  This is implemented in the
same way as HSpice i.e. set the MAXORD option to 1:-

.OPTION MAXORD=1

228. Changed the default value of the DELMIN option from -1 to 1.0e-20.  This
changes the minimum timestep in a transient analysis from (1e-9*TMAX) to
1.0e-20.  This allows many analyses to run that would have once failed.  I am
still experimenting on the best default value here.  The aim is to avoid the
dreaded 'Timestep too small' message as much as possible without hitting
floating point problems.

229. Added colour to plot printouts and fixed the font which seemed to change
on its own.

230. Fixed a bug in the vswitch model.

231. Fixed a crash bug in the plot code caused by having very long command
lines.  A number of static buffers were made dynamic to fix this.

232. Updated the BSIM4 device to version 4.3.0.

233. Fixed a longstanding problem with the plot command crashing if the
first parameter was not a vector.

234. Made BSIM4 device selectable as levels 14 and 54.

*****************************
For WinSpice3 v1.04.16 onwards:-
*****************************

223. Fixed problem where the transient analysis of a PULSE voltage source
would not correctly simulate the pulse edges. This was caused by an old
error in the original Spice3 voltage a current source code.

224. Fixed an infinite loop if an included file doesn't exist.

225. Fixed a parsing problem where a number like +1.0000e-7 would not get
handled correctly and give an error.  The problem is triggered by the '+'
at the beginning of the number.  If the '+' was removed, everything was OK.

226. Fixed an expression parsing bug which meant a line like

B1 1 0 v=2^9

would result in v(1) being 1 volt instead of 512 volts.


*****************************
For WinSpice3 v1.04.15 onwards:-
*****************************

218. Fixed a problem where a line like

    set temp=50

would set the temperature but this was not being given to the a subsequent
analysis.  This is a long-running bug in Spice3 which I had fixed for the

   .option TEMP=50

case some time ago.

219. Added to fix 187 below to also work on G and H sources for compatability
with PSpice.

220. Fixed a bug where the TEMP variable in a behavioural expression was being
returned in Kelvin, not Centigrade.

221. Fixed a bug where a behavioural expression contained TEMP, TIME or FREQ
together with a voltage like v(1), the program would crash.

222. Added support for temperature sweeps with the .TEMP directive.

*****************************
For WinSpice3 v1.04.14 onwards:-
*****************************

211. Added support for TC1= and TC2= options on a resistor line.
This allows each device to have a different temperature coefficient
from the model e.g.

       R1 1 3 56 TC1=.1 TC2=.4

212. Added support for expressions to define the value of R and C
devices e.g.

       R1 5 7 R=V(1)+100
       C3 5 7 C=V(1)+100

The expressions allowed are the same as used in the B non-linear 
dependant sources.  If the expressions contain voltages or currents,
the voltages and currents are those from the DC operating point.

213. Added a DC convergence aid in addition to GMIN and source stepping.
If DC convergence fails, WinSpice will try applying resistive shunts from
all nodes to ground and then retries.  It starts with a shunt value of
1/gmin and then ramps the shunt resistance down by a factor of 10 then
tries again until a shunt value of 1e9 is reached.

214. For PSpice compatability, allow 'RES' to be used for the resistor
model type in addition to 'R':-

       .model <modname> RES(<params>)
       .model <modname> R(<params>)
       
Likewise allow 'CAP' to be used for the capacitor model type in addition
to 'C':-

       .model <modname> CAP(<params>)
       .model <modname> C(<params>)

215. Added code to allow Spice2-style resistors to be defined where
temperature coefficients are specified in the device instancel ine i.e.
     R1 1 2 100k TC=.001,.0003

216. Lots of fixes to .param code for better HSpice support. Fixed some
problems with recursive definitions.

217. Modified the diode code to use 0.01 ohms as the default value for RS
instead of zero.  This allow diode circuits to converge where setting RS=0
does not.  This change will have little or no affect in small signal
conditions (the only condition modelled by Spice anyway) but prevents
queries about convergence problems.  Of course, RS can be specified as 0
if you want to override this behaviour.

An example of a diode circuit which will converge with this change but not
without it is:-

    * Nonconvergent diode circuit
    d1 d 0 diode area=25050e-12
    vd d 0 dc 0v

    .op
    .options temp=120  gmin=1e-15
    .MODEL diode D IS=5.9000e-04 N=1.0e+00

     
*****************************
For WinSpice3 v1.04.13 onwards:-
*****************************

210. Fixed a bug in JFET and MOSFET device models where if an internal
node was created within a device, if a second analysis was run after
the circuit was loaded the internal node would not be implemented.
This bug meant that two identical analyses run consecutively could
give different results.

*****************************
For WinSpice3 v1.04.12 onwards:-
*****************************

208. Improved the compatability of the level 49 MOSFET model to more
closely match HSpice.

209. Added support for parameter expression within single quotes as
used by HSpice.


*****************************
For WinSpice3 v1.04.11 onwards:-
*****************************

206. Disabled more annoying warning messages in the BSIM3 devcie code.
These can be enabled by setting PARAMCHK=1 in the .model line.

207. Fixed a problem where {} were being expanded between .control and
.endc.  This breakes the globbing function in the scripting system.
In fact, there is no mention of this feature in the manual & this has
been corrected also.

*****************************
For WinSpice3 v1.04.10 onwards:-
*****************************

204. Fixed a problem where if the -b and -r command line options were
used to get WinSpice to output results to a file, different results
were obtained than when running WinSpice interactively.  This was being
caused by the simulation being run twice in succession.  The second
execution seems to be being run with some internal variables in an
'unfresh' state.  This latter problem has yet to be fixed though.

205. Fixed the terminal window output to a file using the -o command
line option.  The output had double carriage return characters in it.

*****************************
For WinSpice3 v1.04.09 onwards:-
*****************************

203. Disabled annoying messages coming from BSIM3 devices.

*****************************
For WinSpice3 v1.04.08 onwards:-
*****************************

201. Added the 'M' multiplier parameter to all MOSFET devices.

202. Added a nag message.  This message appears if a feature is used
that I have implemented over and above the basic Spice3 features.
Pressing any key will let WinSpice continue running.  Other than
the nag screen, all the functions of the program are available whether
registered or not.  If you only use standard Spice3 features, you won't
see the nag message. The message is displayed at most once every 5
seconds.  Licensed program users will never see the nag screen.

*****************************
For WinSpice3 v1.04.07 onwards:-
*****************************

199. Added vecmin(), vecmax() and d() vector functions.

200. Added MOS9 device model

*****************************
For WinSpice3 v1.04.06 onwards:-
*****************************

197. Fixed a problem in the parameterisation code with the parameter
stack.  This was causing spurious error messages.

198. Increased the iteration limit in the pole-zero analysis.  This was
preset to 200.  Now it is set to 300 and this seems to work better.  A
.cir file which would not work with 200 iterations works with 300.
Ideally, this needs to be a configurable parameter.

*****************************
For WinSpice3 v1.04.05 onwards:-
*****************************

195. Fixed current and voltage controlled switch devices so they are
now PSpice compatible.

196. More fixes to parameter passing between subcircuits.

*****************************
For WinSpice3 v1.04.04 onwards:-
*****************************

193. Fixed a bug which meant that command files like spinit were not
being processed.

194. Fixed some problems with parameter expansion in nested
subcircuits.

*****************************
For WinSpice3 v1.04.03 onwards:-
*****************************

190. Numerical bugs fixed in the EKV model.  Thanks to Harry Eaton for
pointing these out.

191. Fixed a buffer overflow problem in subcircuit expansion. I wasn't
allowing for very large amounts of expansion of input lines caused by
subcircuit expansion.  I now allow for a 100x size increase!

192. A fix was made to remove (,) from Fxxx lines.  This was already done
for voltage source lines.

*****************************
For WinSpice3 v1.04.02 onwards:-
*****************************

186. Fixed the parsing of Cxxx lines to match Rxxx lines.  This has always
been different for some reason in Spice3.

187. Modifications to handle lines like
    F1 1 2 VALUE=<expr>
    E1 1 2 VALUE=<expr>
as used by PSpice.

188. Better error handling and display in the source parser.

189. Fixed a crash problem when loading files with very long lines.
Caused by a fixed sized buffer in the subcircuit expansion code.

*****************************
For WinSpice3 v1.04.01 onwards:-
*****************************

182. Fixed the writing of binary rawfiles.  They would get written in the
wrong mode and get corrupted.  Evidently, no-one uses binary rawfiles!

183. Fixed a problem caused by expressions within {} like

{ v(1)-v(2) }

Expressions like this cannot use voltages like this because the expression
must be fully resolved when the circuit file is read.  So it treats v(1) as
a non-existant function call.  This should have caused an error message, but
instead it caused the program to lock up or crash.

184. Fixed a problem with nested curly braces e.g. {{FRED}} would cause an
error.

185. Added range checking to the asin() and acos() functions to prevent
domain errors for out of range input values.


*****************************
For WinSpice3 v1.04.00 onwards:-
*****************************

179. Fixed a problem with the .lib directive which could not take a quoted
filename.

180. More fixes to the subcircuit parameter code.  Lots of problems were
fixed in the logic used to expand parameter expressions in nested models
and subcircuits.

181. Implemented *INCLUDE as used in IsSpice netlists.

*****************************
For WinSpice3 v1.03.11 onwards:-
*****************************

172. Fixed the 'let' command to get commands like:-

    let array[10] = 6

to work properly.

173. Noise analysis output format reverted to its original units (i.e. I have
reversed change 99 below). However, if a Spice2 circuit is loaded, any plot or
print commands will be adjusted to the units used by Spice2 for compatability. 

174. Added support for *DEFINE and PARAMS: in the parameterisation code.

175. The behavioural expression parser used in the B circuit element has been
rewritten to allow boolean operators and the condition operator.  This allows
expressions like:-

B3 5 0 V= V(T) < 75 ? 0 : V(T) < 90 ? -5 + V(T) / 15 : 1

to be used.

176. Fixed some quirks in the BSIM1 and BSIM2 devices.  Device parameters vbs,
vgs and vds were returning initial values only and so these have been renamed
to icvbs, icvgs and icvds.  Code to return the expected values of vbs, vgs and
vds has been added (actually, it was already there but there was no way to get
these values - looks like some unfinished work in the original Spice3 code).

177. Changed how memory is allocated again.  The Windows API I was using has
some limitations one of which is that a maximum of 65535 blocks can be
allocated.  WinSpice can hit this limit for some circuits reported by several
users.

178. Added code to the 'source' command to remove comment lines from the deck
before doing much processing.  This fixes some problems that had arisen with
comments in subcircuits.  This removes the need to handle comment lines in
all parts of the code which process circuit files.

*****************************
For WinSpice3 v1.03.10 onwards:-
*****************************

171. Various fixes to remove problems introduced with the new parameter
code.

*****************************
For WinSpice3 v1.03.09 onwards:-
*****************************

167. Fixed problems with .global not being recognised properly.  How I missed
this when I implemented .global I don't know!

168. Fixed a problem where a faulty memory block would be detected if a DC
analysis was interrupted & then resumed.

169. Fixed problems with semiconductor resistors and capacitors tripping up the
library pre-processor code.

170. Preliminary support for parameterised subcircuits.  An example of useage
(a bit forced - its just to show you the syntax) is:-

Basic RC circuit

.param FILTCAP=1.0

x1 1 2 TRUERES { RES=1 CAP=.1u}
*l 1 2 1.0
c 2 0 {FILTCAP}
vin 1 0  pulse (0 1) ac 1

* Resistor model
.subckt TRUERES 1 2 { RES=1 CAP=1u }
r1 1 2 { ((RES <= 2) || (RES > 10)) ? RES : 99 } 
c1 1 2 {CAP}
.ends

* Analysis
.tran  0.1 7.0
.ac dec 10 .01 10
.plot tran  v(2) i(vin)
.plot ac vdb(2) xlog
.plot ac vp(2)
.plot ac gd(v(2))
.end

*****************************
For WinSpice3 v1.03.08 onwards:-
*****************************
165. Fixed a crash problem when running simulations with very large numbers
of output points.  This was tracked down to the memory allocation routines
in the Borland C++ runtime library.  Fixed by replacing malloc(), free() and
realloc() with similar routine which use the Win32 global memory allocation
routines.  WinSpice now survives running a simulation which generated nearly
900000 timepoints and use almost 500Mb of memory!

166. More optimisation to speed up simulation for simulations which generate
a large number of output points (like the one in 165).


*****************************
For WinSpice3 v1.03.07 onwards:-
*****************************

161. Added error checking to the ph() vector function to prevent maths faults
under certain conditions.  Also, fixed other vector functions so that they
free up the memory they use if an error is detected.

162. Fixed problems reading out junction capacitances with the MOS1, MOS2,
MOS3 and MOS6 device models.

163. Fixed a bug in MOS2 and MOS3 devices which caused a miscalculation of
CGS after a OP analysis.

164. Fixed a problem where a node name lookup might fail. This was caused by
the hash function in inpsymt.c not being case insensitive.

*****************************
For WinSpice3 v1.03.06 onwards:-
*****************************

159. Fixed a problem of voltage source name expansion in subcircuits caused
by the recent change to the way subcircuit names are expanded.

160. Added support for handling vi(1,2) etc.


*****************************
For WinSpice3 v1.03.05 onwards:-
*****************************

152. Fixed plot flyback suppression code added in v0.7.  This sometimes ended
suppressing the whole plot.

153. Fixed DC analysis problem where the last voltage step would not be 
analysed.

154. Added progress messages for various analyses and the 'spec' command.

155. Fixed problems in the 'listing' command where long lines would not get
displayed properly.

156. Improved handling of errors in the 'source' command.

157. Fixed problems with continuation lines in library files.  Merging of
continuation lines would fail if the library file did not start with a
comment.  Warning messages were also not getting displayed.

158. Fixed a potential crash problem in library file processing.

*****************************
For WinSpice3 v1.03.04 onwards:-
*****************************

145. Fixed problems handling vector indexing (vec[index]) and ranges
(vec[x, y]).

146. Added support for .global to control node name expansion in subcircuits

147. Added the gd() function to calculate group delay.  Also added the deg()
and rad() functions for angular conversions.

148. When automatically generating WinSpice commands when loading a Spice2
circuit, WinSpice now adds 'set units=degrees' so that phase plots are in
degrees by default.

149. Fixed a problem in BJT noise analysis which could attempt to calculate
log(0).

150. Fixed a buffer overflow in the code which writes to the terminal window.

151. Fixed a problem where the an internal array to take the output results
could be undersized if the number of output equations in the circuit changed
between 2 analyses.  The result was that a memory block end overrun would be
detected when the circuit storage was freed up e.g when a new circuit was
loaded.  This problem occurs when a noise analysis is performed after a dc,
ac or op analysis because the noise analysis adds an extra output equation
to the circuit.  This problem will be found in most if not all ports of Spice3.


*****************************
For WinSpice3 v1.03.03 onwards:-
*****************************

143. Fixed crash when '=' was omitted in 'alter @q1[temp] = 0'.

144. Fixed a bug in recognition of the version of the BSIM3 model.


*****************************
For WinSpice3 v1.03.02 onwards:-
*****************************

140. Fixed crash when 'resume' command is used when no circuit is loaded.

141. Added code to allow plot colours to be chosen using 'set colorN=colour' where
N can be between 0 and 19.  'colour' is a colour name which can be any of the following:-

    white
    black
    lt_red
    lt_green
    lt_blue
    lt_yellow
    lt_cyan
    lt_magenta
    red
    green
    blue
    yellow
    cyan
    magenta
    grey
    brown
    orange
    pink

color0 is used for the plot background (but this doesn't work yet - its always white) and
color1 is the colour used for the grid and text. color2 to color19 are the plot colours.

142. Fixed problems with BSIM1 and MOS2 devices that I accidentally introduced.

*****************************
For WinSpice3 v1.03.01 onwards:-
*****************************

138. Fix plot code to allow 'plot vector1 vs -vector2' to work properly.  Previously, this
would get evaluated as 'plot vector1 vs-vector2' which caused an error and isn't quite what
was meant.

139. Fixed a crash if <RETURN> was pressed on an empty line.

*****************************
For WinSpice3 v1.03.00 onwards:-
*****************************

121. Fixed a problem in the EKV model where the 'scale' option was not being used properly when
calculating model capacitances.

122. A fix has been made to prevent mag() being added to plot expressions after an AC analysis.
If mag() or ph() is already used in the expression, WinSpice won't add extra mag() and ph()
stuff.  For example, if the following was entered to plot the result of an AC analysis:-

plot db(mag(((v(11))+(v(3)))*2))

then earlier version of WinSpice would turn this into:-

plot db(mag(((mag(v(11)))+(mag(v(3))))*2))

This expansion was added to WinSpice for compatability with Spice2 circuits.  However, in this
case the user has already used the mag() function so the extra mag() calls are a nuisance.

123. Added support for the '.option scale=x' option to the MOS1, MOS2, MOS3, MOS6, BSIM1, BSIM2,
BSIM3 and BSIM4 device models.

124. Fixed a lockup problem which occured when trying to sort arrays of vectors by name.

125. Fixed a problem that occured if a Qxxx line defined NS (substrate node).  This caused a
spurious error message and would not allow the simulation to run.

126. Fixed a problem where v(x,y) would get expanded to v(x)-v(y).  This could give the wrong
answer is expressions like v(x,y)*v(a,b) were used.  So v(x,y) now get expanded to (V(x)-v(y)).

127. Added missing 'unlet' and 'setscale' commands to the manual.

128. Updated the BSIM3SOI model to v1.3

129. Fixed problems with plotting polar plots.  The automatic mag() function was getting in the
way again (see item 122 above).

130. Added MOSFET levels 49 (BSIM3).  This is the same as selecting level 8.  In addition,
WinSpice now supports v3.1, v3.2 and v3.2.2 of BSIM3.  These can be selected by adding
'VERSION=3.1', 'VERSION=3.2' or 'VERSION=3.2.2' to the .MODEL line.  If 'VERSION' is missing,
v3.2.2 is assumed.

131. Added the 'rawfile' command.

132. Fixed a problem with the redrawing of plots when the 'vs' keyword is used.  The plots
were being redrawn with the wrong x-axis.

133. Added the Settings->Font menu to allow the user to pick the font.

134. Correction made to the EKV model to correct the effective channel width calculation to
take into account the M parameter.

135. Fixed a problem where in a line like 'b1 1 0 v=v(3,4)' the v(3,4) bit would not be
correctly parsed and caused a syntax error message to be displayed.  This appears to be a
bug I introduced by me a long time ago because the original Spice3f4 code is correct.

136. Fixed a problem where 'save all @q1[ic]' would only save @q1[ic].  Also added the ability
to say 'save none'.  Vectors in a save command are additive left-to-right so the command
'save none all @q1[ic]' will save all node voltage, all voltage source branch currents and the
collector current for Q1.

137. Fixed a problem where the 'run' command would not rerun the previous analysis.


*****************************
For WinSpice3 v1.02.00 onwards:-
*****************************

113. Fixed crashing bug when printing a plot window.

114. Fixed a problem where the plot File->Print Setup dialog was not passing settings to the
File->Print dialog.

115. Improved memory management when extending vector length during an analysis.  This makes
the efficiency of the system realloc() routine have a much lower impact on the speed of WinSpice.

116. Fixed a crash problem which occured after a .cir file was editied and WinSpice resimulated
the circuit.

117. Added the 'scale=xxx' option to .option lines.  This scales dimension parameters in .model
lines.  Currently, this only works with the EKV MOSFET model.

118. Reinstated the Spice3 minimum timestep limit to prevent floating point faults when simulating
non-convergent circuits.  This limit can still be diasablted by using '.option delmin=0'.

119. Modified RES and CAP models to be largely compatible with PSPICE.  The TC1 and TC2 parameters
have been added to the CAP model and TC1, TC2, VC1 and VC2 parameters have been added to the
RES model.

120. The SW switch model now takes the VON and VOFF model parameters and also has the alias
VSWITCH for compatibility with PSPICE.  Likewise, the CSW switch model now takes the ION and
IOFF parameters and has the alias ISWITCH for compatability with PSPICE.


*****************************
For WinSpice3 v1.01.00 onwards:-
*****************************

107. Code modified so that if a .model parameter is not recognised then this is treated as a
warning not a fatal error.  This allows analyses to run.

108. Improved handling of things like v(x,0) etc.  Multiple clauses of this form will be expanded
to Spice3 form (useful in 'plot' lines).

109. Fixed a bug in bsim3soi model which caused a log() domain error.  Checking of log() and exp()
calls has been enabled.  An error will be displayed giving the file and line number of the caller
which will help track down maths errors.

110. Added the EKV v2.6 MOSFET model from Ecole Polytechnique Federale de Lausanne (EPFL).

111. Fixed problem where the POLY() keyword would not be recognised if written in mixed case e.g.
pOLY() or Poly() would not be recognised.

112. Added parameter checking to 'tran' command to prevent floating point errors if no parameters
are supplied.

*****************************
For WinSpice3 v1.00.00 onwards:-
*****************************

87. Added the DERA STAG SOI model v2.6.  See http://www.micro.ecs.soton.ac.uk/stag/ for details.

88. Fixed problems parsing a vector of the form '[ x -y z ... ]' where the numbers in the
vector were prefixed with unary minus or plus.

89. Got rid of write-only model device and instance parameters because of problems this
causes to the 'alter' command.  If a line like

alter @vinput[sin]= [ 0 $vain 10e3 ]

was used, the parser would attempt to get the value of @vinput[sin].  This caused an error
because the 'sin' parameter was flagged as write-only.  The reason the parser behaves this
way is because it treats assignment as an operator like a C compiler does.  Strangely, the
original Spice3 code includes provision for reading write-only parameters so it looks like
write-only parameters are a more recent modification.  However, some models might report 
and error if they do not contain code to read write-only parameters - let me know if you
find one.

90. Removed the 'ic' write-only parameter for the vsrc device from the documentation.
There was no code for it anyway.

91. Allowed for the 'sourcepath' variable to be a list or a string.  If sourcepath was
changed with the set command as follows:-

	set sourcepath=c:\winspice3\examples

then a subsequent 'source astable.cir' would not find astable.cir in c:\winspice3\examples.
The problem was caused by the fact that sourcepath is meant to be a list, but setting the
string with the command above makes it a string.  Either a string or a list is now allowed.

92. Fixed a problem that occurs when a command like 'plot all vs input' is entered where
'input' is the scale.  This was causing a memeory block to be freed twice.

93. Corrected a problem caused by fix 89 above.  Typing 'show all' would cause a GPF.  More
work is needed to make sure that all input-only parameters can be read back for the 'alter'
command.  The BJT and BSIM1 models should work.  The rest I'll sort out later.

94. Some fixes made to allow the 'alter' command to work properly.  A new example 'altertest.cir'
tests out the alter command for a BJT model.

95. Fixed a problem with the Windows code which could cause terminal window text to appear to be
double spaced.

96. The terminal window size an position is now recorded in wspice3.ini.

97. Fixed a problem discovered with a valve model where WinSpice was being asked to evaluate
pow(0, -0.8) or similar.  This causes a maths error.  To avoid this, I have made WinSpice return
0 for this expression.

98. Added the BSIM4 device.

99. Fixed the noise analysis so that the noise results are in units of V/root Hz instead of
V squared/Hz.  Anyone used to using Spice2, PSpice and other Spice programs will expect it
this way.

100. Added code to handle Spice2 netlists properly when loaded from the source command.  This
attempts to generate some output by converting Spice2 directives into Spice3 commands and then
execute them.  If the input circuit contains .control or an Spice3 commands, no attempt is
made to do this conversion - the circuit is loaded as in earlier versions of WinSpice.

101. Fixed a problem with batch mode operation when winspice was started with the -b option.
The program would generate a page fault after running the simulations.

102. A minor change was made so that when a vector is looked up e.g. after a print or plot
command, the vector would be searched for in all plot lists until found.  Previously, the
vector would only be looked up in the current plot.  This was awkward for the noise command
which generates two plot lists and sets the current plot to integrated noise results.  This
meant that 'plot onoise_spectrum' would not work after a noise analysis and was causing some
confusion.

103. For easier compatibility with Spice2, using 'plot onoise' after a noise analysis is
equivalent to 'plot onoise_spectrum'.  Likewise, 'plot inoise' is equivalent to
'plot inoise_spectrum'.

104. Code modified so that for every circuit line read in by WinSpice is associated the original
filename and line number.  If an error or warning is generated when the circuit is loaded, the
filename and line number is also displayed.

105. The 'listing' command now shows the filename and line numbers relating to the original source
files together with any errors or warnings found when the circuit was loaded.  Previous versions
of WinSpice would cause lines to be renumbered destroying any chance of tracking down a problem
to a line in the circuit.

106. Added code parsing code for diodes, voltage sources and current sources to detect if they
have been shorted out and display a useful warning message.  In each case, the shortage component
is not loaded into the circuit.


*****************************
For WinSpice3 v0.8 onwards:-
*****************************

76. Corrected a problem where a plot window goes haywire if a vector containing an 'almost'
constant value is plotted.  Fixed by putting back some code commented out by someone at
Berkeley (so I'm not the first to find this problem).

77. Fixed any command which takes a filename to handle a quoted filename.  This is needed
to cope with long filenames which contain spaces.  Also, removed treatment of '\' in a string
as an escape character to prevent the mangling of file paths.

78. Added the 'cross' and 'strcmp' commands to the manual.

79. Fixed a problem where using x^y in dependent voltage and current source expressions could
cause a floating point exception.  This was caused by trying to take the log of zero under some
circumstances.  Fixed by substituting 1e-30 if zero is supplied as a parameter.

80. Improved the command line to include editing and history using cursor keys like doskey.

81. Improved formatting of the output of the 'print' command

82. Added the sum() vector function to calculate the sum of all elements of a vector.

83. Fixed a problem where ticmarks would not get redrawn on a plot window when it was resized.

84. Fixed a problem where the transient analysis maximum step size was getting set up incorrectly
if the TMAX parameter to 'tran' or '.tran' was omitted.  The code now agrees with the user manual
in that it now sets the maximum step size to min(TSTEP, (TSTOP-TSTART)/50).

85. Implemented the '.option rshunt=x' option.  This places a resistor between all voltage nodes
and ground.  This greatly helps the majority of circuits to simulate properly, particularly if the
user is not aware of the quirks of standard Spice.  By default, rshunt is inactive.  It can be 
enabled by using '.option rshunt=1e9' to set the shunt resistor value (100Meg in this case).

86. Lots of fixes to reduce memory leakage as the program runs.  The program still leaks memory, but at
a much lower rate now.


*****************************
For WinSpice3 v0.7b onwards:-
*****************************

74. Fixed a floating point error which can occur when a plot window is resized.  A plot window
can no longer be resized below a minimum size.

75. Fixed numerical overflow problems with the BSIM1 model caused by a complete lack of code
to limit the values passed to the exp() function.  During simulation, input values could
exceed the maximum value allowed by exp().

*****************************
For WinSpice3 v0.7a onwards:-
*****************************

71. Fixed problems with lines of the form
	alter r1 = 10k
This was caused by another 'improvement' to improve the error message from incorrect use
of the 'alter' command.

72. Corrected a bug introduced when making change 53 below. If the x-axis of a plot was
decreasing, no plot line would be drawn.

73. Looking into BSIM1 maths error problems. Seems to be endemic to the BSIM1 code.

*****************************
For WinSpice3 v0.7 onwards:-
*****************************

50. Corrected the drawing of comb plots (e.g. if 'combplot' is given in a plot command).
The vertical lines would be drawn to the bottom of the graph instead of to the x-axis at
y=0.

51. Fixed a problem with the asciiplot command which occured if the plot title was longer
than about 80 characters.  Some integer maths was getting evaluated to a negative value
but was being evaluated as a very large unsigned value.  This caused up to 2 billion spaces
to be printed to centre the title on the page!

52. Corrected problem with pointplot plots where the plot window was not being redrawn
properly.

53. Fixed a problem where 'flyback' would be seen on a plot if drawn using DC analysis
which uses multiple sources e.g. to draw a transistor charactersitics.  The resultant plot
contains multiple curves but, when the plot was redrawn, the end of one curve was being
connected to the start of the next resulting in linking up of the plots.

54. Improved plot window redraw speeds by exiting early if zero length lines are being drawn
which could occur if closely spaced points are being drawn.

55. Fixed an occasional fatal error of the form 'txfree(): bad block signature'.  This occured
when a circuit structure was being freed up.

56. Fixed a problem with binary rawfile output using the 'write' command.  It turned out that the
rawfile could not be read back without getting an error message.

57. The 'help listing' command now shows all the possible listing possibilities.  The [expand] option
was missing.

58. Changed subcircuit expansion so that the expanded names now include the subcircuit reference.

59. Added support for vbe(), vce(), vb(), vc(), ve() in .plot lines etc.  These expand to use the
q?#base, q?#collector and q?#emitter output vectors, but these are currently voltages inside the
BJT model, not terminal voltages as you might expect.  I will try to fix this anomaly soon.

60. Fixed a problem with the 'sens' command when doing AC sensitivity.  A parsing error was preventing
the command from working.  A new example .cir file (sens.cir) which illustrates sensitivity analysis
has been added to the examples directory.

61. Disabled redirection for 'define' commands.  The '>' and '<' characters can now be used in
user defined function without problems (see sens.cir).

62. Added experimental recording of branch currents for resistors and capacitors.  This can be enabled
by adding the line

	.option resbranch capbranch

to your circuit.  With branch currents enabled, capacitors are now replaced by 100gigohm resistors
during operating point analysis.  This might help some circuits work properly and probably more
accurately simulates a real capacitor.  Be aware that with branch currents enabled, some adjustments
may be needed to get the circuit to converge.

63. Fixed problems with the .lib command and nested subcircuits (thanks to Fridger Schrempp).  Another
problem where the wrong subcircuit could get extracted from a library was also fixed (thanks to Fridger
Schrempp again for highlighting the problem).

64. More fixes to the alter command.  This now correctly accepts all three formats.

65. Removed spurious "Warning: vec_free: plot ptr is 0" message that sometimes occurred.

66. Fixed a problem where iplots could not be zoomed because the command line stored with the plot was
incorrect.

67. More fixes to cope with filenames containing space characters in .include or .lib lines.

68. Modifications made to allow vectors to be defined in 'let' and 'alter' commands using the form
'[ x y z ]' e.g. 'let params = [ 1 0.15 2.6 ]' which defines a three element vector.  The standard
Spice3 manual says this is possible, but I can't see that it was ever implemented.  It is now
(well in WinSpice it is!).

69. Fixed problems with writing lines like
	let rindex[index] = 23
which used to give an error message like 'left-hand expression is too small (need xx)'.  The code
seems to imply that 'let' can only assign a complete vector instead of only a few values in a vector
at a specified index, but I can't see why so it has been fixed.  A case of clutching defeat from the
jaws of victory - the original Spice authors seem to have broken working code here.

70. Reduced memory leakage during subcircuit expansion.


*****************************
For WinSpice3 v0.6 onwards:-
*****************************

45. Added the 'delmin' option to the '.option' directive to set the minimum allowed timestep
for transient analyses.  A value of 0 (the default) disables checking.  This replaces the
older fixed value in Spice3 of 1e-9*TMAX which causes so much trouble.

NOTE: this change is an improvement of fix 28 below which was introduced in WinSpice v0.4.
Having a minimum timestep limit is useful for trapping non-convergent circuits before
floating point maths starts going out of range.

46. Fixed a problem with sensitivity analysis where a 'txfree(): Bad block signature' message
could be displayed.

47. Added support for writing comma-separated files using the 'write' command.  If a filename
is given and it has the .csv extension, plot data is written to the file in comma-separated
format so that it can be imported into a spreadsheet.

48. Fixed a problem with the 'alter' command not recognising model or device parameters.

49. Updated the BSIM3 model to v3.2.2 and added in our fixes.  The maintainer of BSIM3 has been
contacted about temperature-related bugs in the current BSIM3 release.


*****************************
For WinSpice3 v0.5 onwards:-
*****************************

37. More memory leaks fixed in expression evaluator code.

38. Fixed a problem introduced by me during recent changes.  Basically, the 'print all'
command was not working properly.  This now works as in earlier versions.

39. Corrected incorrect code for the deriv() function which was causing GPFs.

40. Added zooming to graph windows.  Click and drag to select a region of a graph and
a new plot will be drawn when the mouse button is released.

41. Fixed a crash which could occur when reading in zero-length include files.

42. Fixed a problem with opening spinit if WinSpice was installed in a directory with a
    space character in the path e.g. "c:\Program Files\winspice".

43. Fixed some typos in the tutorial document.

44. Fixed problem where a quoted string in a command would cause WinSpice to lock up.
A command like 

    cd "elmer fudd"

or 

    cd 'elmer fudd'

will now work properly.


*****************************
For WinSpice3 v0.4 onwards:-
*****************************

20. In previous releases, typing 'edit' would launch notepad and display the
current circuit for editing.  However, this caused WinSpice to be suspended
so that its windows would not redraw so it appeared to be dead.  The edit
now launches notepad, but does not wait for it to terminate.  A new feature
has been added to WinSpice in that it now monitors changes made to the circuit
file.  So, if you have edited the circuit in notepad and want to reload it into
WinSpice, just save the file.  As soon as WinSpice sees the change, it will
automatically issue a new 'source <filename>' command to reload the circuit.

21. Fixed a problem with the library code which was causing spurious, apparently
random crashes when a circuit was loaded.  WinSpice now seems much more reliable.

22. Fixed a problem with the alter command which could crash if the '=' character
was omitted e.g. with a line like 'alter r1 10k'.  The alter command now works
with and without the '=' character i.e. 'alter r1 10k' and 'alter r1=10k' now work.

23. A compatibility problem with some Spice2 opamp macromodels has been fixed.
Basically, lines like

            GO1  45   99   (99,40) 4E-3

cause a problem because Spice2 allows a pair of node numbers to be grouped with
'(,)'.  Spice2 ignores these characters and treats this line the same as

            GO1  45   99   99 40 4E-3

WinSpice now also ignores these characters (in fact it replaces them with spaces
when the circuit is loaded).

24. Added code to comment out any lines beginning with '.view'.  This is an
option specific to Intusoft version of Spice3. However, this modification was made
so that the free SpiceNet schematic editor program given away by Intusoft
(http://www.intusoft.com).  When SpiceNet saves a schematic, it also saves a .cir
file.  Now, if you open this .cir file with WinSpice, you can simulate the schematic
by just saving it.  WinSpice will reload the circuit file.  Make sure the you add
the user command '*#run' to your circuit.

25. Fixed the 'save' command so it now saves vectors with names like 'v(1)' properly.
Previously, vectors with names containing '(' would not get saved (this bug is
in the original Spice3f4 sources).

26. Got the 'iplot' to work properly, partially fixed by item 25 above.  Also updated
the manual because the original manual did not explain that iplot's are a sort of
visual trace and show up under the 'status' command and can be deleted with the
'delete' command.

27. Fixed some problems with temperature handling.  Some of the basic models like
BSIM1 and BSIM2 seem to be implemented incorrectly here.

28. Fixed a problem with transient analyses.  The original Berkeley code was imposing
a minimum limit to the time delta using the undocumented formula 1e-9*TMAX (see the
User Guide in the section describing .TRAN for the meaning of TMAX). If a transient
analysis hits this limit, a 'Timestep too short' message was being printed but with no
guidance given as to how to fix the problem.  Removing a check for this limit seems to
make some circuits work properly with no apparent ill effects.

29. Lots of memory leaks fixed, although there are some left.  This was partly done by
adding a new variable to control the number of circuits stored by WinSpice3.  Every
time a new circuit is loaded, if the number of in-memory circuits exceeds the value of
'maxcircuits', the oldest circuit is deleted.  The value of 'maxcircuits' defaults to 1
which helps limit memory usage.

30. Printer menu items for plot windows now work properly and use standard dialog boxes.

31. 'help' command with no parameter now gives some useful hints (this form of 'help'
command is in the original Berkeley sources but it was not being used).

32. Updated the BSIM3 device model to v3.2.

33. Fixed the history command list.  This was being screwed up by some dodgy code from
the original Spice3 code.

34. Another correction to the POLY expansion stuff to handle coefficients like '1.9M'
which were not being converted to the form of number expected by Spice3 i.e. 1.9e-3.
This now give better compatibility with Spice2 models that can be found on the
internet.

35. More memory leaks fixed, particularly in the command line code.  Spice was
pointlessly saving all commands entered from the terminal window on a linked list. It
now only does this if a foreach, dowhile or while command is being entered and the
commands are freed when 'end' terminates these composite commands.

36. Fixed a problem where the 'show' command would not redirect to a file.  Possibly
more of these are lurking.


*****************************
For WinSpice3 v0.3 onwards:-
*****************************

15. The 'spec' command has been added to the User Manual.

16. The BSIM3 and BSIM3SOI models now work.

17. Fixed a problem with parsing the .cir file when looking for POLY
directives to expand.  The POLY directives were not getting expanded.

18. Plot windows and the terminal window now have menus.  Circuits can be
loaded and run using the 'File'/'Open' menu sequence in the terminal
window.

19. Editorial changes to the User Manual have been made.  Added a description
of program installation and use at the head of the document.  Removed all
references to command completion.


*****************************
For WinSpice3 v0.2 onwards:-
*****************************

8. There is a new spec command supplied by Anthony Parker 
(anthonyp@sr.hp.com).  I haven't yet worked out how to use it, but
if you type 'oldhelp spec' you get some hints.  I will include this
command in the documentation ASAP.

9. WinSpice3 includes the BSIM3 and BSIM3SOI models.  Problem is,
they don't work yet so don't bother trying.  The drain-source current
always comes out as zero when I run the supplied tests - anyone have
any ideas?

10. Plot windows and the terminal window can now be resized by
dragging the borders.

11. WinSpice includes a new level 2 JFET model (also by Anthony
Parker, anthonyp@sr.hp.com).  Again, no details in the User Guide
yet.

12. WinSpice no longer hogs the processor when waiting for keyboard
input (thanks to Horacio Gonzalez for pointing this out).

13. The 'cd' command no longer crashes if typed on its own (thanks to
Sparc Han for reporting this).  It now displays the current directory.

14. The plot windows now have a print option on the system menu (click
the top left corner of the window.  The Print Setup option still doesn't
work though.


*****************************
For WinSpice3 v0.1 onwards:-
*****************************

1. There is an item on the plot window system menu to copy the
contents of a plot window to the clipboard.  This lets you load plot
graphics into word processor documents.

2. This port fixes lots of severe memory management problems which
existed in the original code.  These cause lots of crashes when I
first compiled the code.  It now seems quite stable.

3. The scripting language (based on the Unix C-Shell) now works as
advertised.  The original Berkeley code contained a fundamental
error, duplicated about 100 times in the code, which meant that this
feature does not work on most, if not all ports of Spice3.  However,
scripts now work as advertised in the documentation.

4. I have added support for the POLY statement from Spice2 so that
many device models from Spice2 and PSpice, particularly opamp macro
models, can still be used.  POLY has been replaced by an expression
in Spice3 so what happens is that in WinSpice3 the POLY statements
are expanded to a Spice3 expression before the circuit is analysed.

5. I have added support for libraries of concatenated models as
used by PSpice.  This is done by using the .lib directive in the .cir
files.  WinSpice3 searches for any unresolved models in the file
specified on the .lib file and extract the required model lines
before the circuit is analysed.

6. A separate pre-processor, capable of performing model library
searches and POLY statement expansion is also provided (spicepp.exe). 
This program is essentially embedded in the WinSpice3 executable. 
However, having a separate pre-processor is handy sometimes.

7. There are loads of demo circuits in the examples directory. Some
illustrate the use of the scripting language to perform quite complex
tasks with very little effort (see examples\bjt.cir for example).



After installation, the following files will have been installed:-

WSPICE3.EXE             The simulator.
HELP.EXE                A stand alone help browser.
PROC2MOD.EXE            Converts process characterization files
                        to Spice3 BSIM1 MOS model definitions.
SCONVERT.EXE            Converts between ascii and binary spice
                        data files (".raw" files).
MULTIDEC.EXE            A utility for decomposing coupled lossy
                        transmission lines into equivalent uncoupled
                        lines.
SPICEPP.EXE		A Spice pre-processor (built into WinSpice3)

LIB\HELPDIR\SPICE.TXT   On-line information for spice3.
LIB\HELPDIR\SPICE.IDX   Index for spice.txt, generated with
                        the program "makeidx.exe".

LIB\SCRIPTS\SPINIT      Spice/nutmeg commands executed at startup.
LIB\SCRIPTS\SETPLOT     A script for the command "setplot".
LIB\NEWS                A start up message of your choosing.
LIB\MODELS\ZMODELS.LIB	A device model library from Zetex

DOC\SPICEMAN.DOC        A SPICE manual in Word format
DOC\TUTORIAL\*.*	A tutorial in Word format and some example files

EXAMPLES\*.CIR          Lots of circuit examples
LIB\                    Utility scripts and help files

DEMO                    Demo script
DEMO.CIR                Demo circuit (run from DEMO script)
DEMO1.CIR               Demo circuit (run from DEMO script)
DEMO2.CIR               Demo circuit (run from DEMO script)
LF156                   Opamp model used by the demo


Devices and Analyses supported in WinSpice3
-------------------------------------------

For reference, the following is a list of all devices and their
common abbreviation in WinSpice3:

        asrc:   arbitrary voltage/current source
        bjt:    bipolar junction transistor
        bsim1:  detailed MOS model
        bsim2:  detailed MOS model, revised version of bsim1
        bsim3:  latest MOS model
        cap:    capacitor
        cccs:   current-controlled current source
        ccvs:   current-controlled voltage source
        csw:    current controlled switch
        dio:    diode
        ltra:   lossy transmission line
        ind:    inductor
        isrc:   current source
        jfet:   Junction FET
        jfet2:  Parker-Skellern JFET model
        mes:    MES FET (GaAs)
        mos1:   MOS, simplest analytic model, fastest
        mos2:   MOS, middle complexity and accuracy
        mos3:   MOS, most complicated, most accurate
        mos6:   MOS, new, fast analytic, short-channel
        res:    resistor
        sw:     switch
        tra:    lossless transmission line
        urc:    uniform RC line
        vccs:   voltage-controlled current source
        vcvs:   voltage-controlled voltage source
        vsrc:   voltage source

The following is the corresponding list of analyses:

        op:     DC operating point
        dc:     DC transfer curve
        tf:     Small signal transfer function
        ac:     AC (frequency domain)
        tran:   transient
        pz:     pole-zero
        disto:  distortion
        noise:  noise
        sense:  sensitivity

